package com.senai.projeto_auth_ws;

import lombok.Data;

@Data
public class PedidoAutorizacao {
    private Long alunoId;
    private String motivo;
}
