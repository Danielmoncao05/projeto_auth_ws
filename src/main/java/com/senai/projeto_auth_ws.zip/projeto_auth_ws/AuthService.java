package com.senai.projeto_auth_ws;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthService(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public Usuario authenticate(String username, String password) {
        return usuarioRepository.findByUsername(username)
                .filter(user -> passwordEncoder.matches(password, user.getPassword()))
                .orElseThrow(() -> new RuntimeException("Credenciais inválidas"));
    }

    public Usuario register(String nome, String username, String password, Role role) {
        Usuario user;
        switch (role) {
            case ALUNO -> user = new Aluno();
            case PROFESSOR -> user = new Professor();
            case AQV -> user = new AQV();
            default -> throw new IllegalArgumentException("Role inválido");
        }
        user.setNome(nome);
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password));
        user.setRole(role);
        return usuarioRepository.save(user);
    }
}


