package com.senai.projeto_auth_ws;

public enum Role {
    ALUNO, PROFESSOR, AQV;
}
