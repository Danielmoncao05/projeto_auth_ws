package com.senai.projeto_auth_ws;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;
    private final JwtUtil jwtUtil;

    public AuthController(AuthService authService, JwtUtil jwtUtil) {
        this.authService = authService;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> payload) {
        String username = payload.get("username");
        String password = payload.get("password");
        Usuario user = authService.authenticate(username, password);
        String token = jwtUtil.generateToken(user.getId(), user.getUsername(), String.valueOf(user.getRole()));
        return ResponseEntity.ok(Map.of("token", token));
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> payload) {
        String nome = payload.get("nome");
        String username = payload.get("username");
        String password = payload.get("password");
        Role role = Role.valueOf(payload.get("role"));
        Usuario user = authService.register(nome, username, password, role);
        return ResponseEntity.ok(Map.of("message", "Usuário cadastrado com sucesso", "id", user.getId()));
    }
}
