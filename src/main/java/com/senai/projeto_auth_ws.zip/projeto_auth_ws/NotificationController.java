package com.senai.projeto_auth_ws;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Controller;

@Controller
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @MessageMapping("/notify")
    public void processNotification(@Payload NotificationMessage message) {
        String destination = "/topic/" + message.getDestination();
        notificationService.notify(destination, message);
    }
}
