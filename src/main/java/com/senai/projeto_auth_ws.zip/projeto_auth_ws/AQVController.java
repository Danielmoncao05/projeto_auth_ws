package com.senai.projeto_auth_ws;


import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class AQVController {

    private final SimpMessagingTemplate messagingTemplate;

    public AQVController(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    @MessageMapping("/aprovar")
    public void aprovarPedido(RespostaAutorizacao resposta) {
        // Envia para o professor e para o aluno
        messagingTemplate.convertAndSend("/topic/professor", resposta);
        messagingTemplate.convertAndSend("/queue/aluno-" + resposta.getAlunoId(), resposta);
    }
}
