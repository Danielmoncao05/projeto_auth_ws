package com.senai.projeto_auth_ws;

import jakarta.persistence.Entity;

@Entity
public class AQV extends Usuario{
}
