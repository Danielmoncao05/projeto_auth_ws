package com.senai.projeto_auth_ws;


import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

@Controller
public class AlunoController {

    private final SimpMessagingTemplate messagingTemplate;

    public AlunoController(SimpMessagingTemplate messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }

    @MessageMapping("/pedido")
    public void enviarPedido(PedidoAutorizacao pedido) {
        // Envia o pedido para a AQV
        messagingTemplate.convertAndSend("/topic/aqv", pedido);
    }
}
