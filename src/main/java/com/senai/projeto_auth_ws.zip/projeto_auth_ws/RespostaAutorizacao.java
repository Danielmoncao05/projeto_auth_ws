package com.senai.projeto_auth_ws;


import lombok.Data;

@Data
public class RespostaAutorizacao {
    private Long alunoId;
    private boolean aprovado;
    private String observacao;
}
